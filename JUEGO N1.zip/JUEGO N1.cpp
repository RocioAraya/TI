#include <stdio.h>
#include <stdlib.h>
#include <time.h>

main()
{
	int NumeroSecreto, NumeroIngresado, Puntaje=10;
	
	srand(time(NULL));
	NumeroSecreto = 1+rand()%(999-1+1);
	
	printf("\t\t\tEste juego consiste en adivinar un numero que se genera automaticamente");
	printf("\n\n* Tiene 10 intentos *");
	
	printf("\n\nPor favor ingrese un numero del 1 al 999: ");
	
	for(int i=1; i<10; i++)
	{
		scanf("%d", &NumeroIngresado);
		
		if (NumeroSecreto < NumeroIngresado)
		{
			printf("El numero secreto es menor y se encuentra entre %d y %d", 1, NumeroIngresado-1);
		}
		
		if (NumeroSecreto > NumeroIngresado)
		{
			printf("El numero secreto es mayor y se encuentra entre %d y %d", NumeroIngresado+1, 999);
		}
	}
}

