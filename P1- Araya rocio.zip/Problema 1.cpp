#include <stdio.h>
#include <stdlib.h>

void Carga(int Orden, float Vec[50]);
void Mostrar(int Orden, float Vec[50]);
void Pausa();
int MayorNota(int Orden, float Vec[50]);


main (){
	float Alumnos[25];
	int N,Leg;
	
	printf("Ingrese la cantidad de Alumnos\n");
	scanf("%d", &N);
	Carga(N, Alumnos);
	Mostrar(N,Alumnos);
	Leg=MayorNota(N,Alumnos);
	printf("El legajo del alumno con mayor promedio es: %d\n", Leg+1);
	printf("Con un promedio de: %.2f\n", Alumnos[Leg]);
	Pausa();
}


int MayorNota(int Orden, float Vec[50]){
	int i, Legajo;
	float Mayor=0;
	
	for(i=0; i<Orden;i++){
		if (Vec[i]>Mayor){
			Mayor=Vec[i];
			Legajo=i;
		}
	}
	return Legajo;
}

void Carga(int Orden, float Vec[50]){
	int i;
	for (i=0; i<Orden; i++){
		printf("Ingrese el promedio del alumno %d:\n", i+1);
		scanf("%f", &Vec[i]);
	}
}


void Mostrar(int Orden, float Vec[50]){
	int i;
	printf("Contenido del vector alumnos\n");
	for (i=0;i<Orden;i++){
		printf("Alumno %d: %.2f\n", i+1,Vec[i]);
	}
}


void Pausa(){
	printf("\n\n");
	system("pause");
}
